package com.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dto.Report;
import com.exceptions.PatientIdNotFoundException;
import com.exceptions.ReportIdNotFoundException;
import com.repository.IfcPatientRepository;
import com.repository.IfcReportRepository;
import com.service.IfcReportService;
import org.springframework.stereotype.Service;
@Service
public class ReportServiceImpl implements IfcReportService {
	
	@Autowired
	private IfcReportRepository reportRepository;
	@Autowired
	private IfcPatientRepository patientRepository;
	@Override
	public Report addReport(Report report) {
		return reportRepository.save(report);
	}

	@Override
	public Report updateReport(Report report) throws ReportIdNotFoundException{
		if(reportRepository.existsById(report.getReportId())) {
			Report r = reportRepository.findById(report.getReportId()).get();
			r.setDateOfReport(report.getDateOfReport());
			r.setDescriptionOfReport(report.getDescriptionOfReport());
			r.setVisualAcuity(report.getVisualAcuity());
			r.setVisualAcuityDistance(report.getVisualAcuityDistance());
			r.setVisualAcuityNear(report.getVisualAcuityNear());
			reportRepository.save(r);
			return r;
		}
		else throw new ReportIdNotFoundException("Report Not Found");
	}

	@Override
	public Report removeReport(int reportId) throws ReportIdNotFoundException {
		if(reportRepository.existsById(reportId)) {
			Report r = reportRepository.findById(reportId).get();
			reportRepository.deleteById(reportId);
			return r;
		}
		else throw new ReportIdNotFoundException("Report Not Found");
	}

	@Override
	public Report viewReportByReportId(int reportId) throws ReportIdNotFoundException {
		if(reportRepository.existsById(reportId)) {
			return reportRepository.findById(reportId).get();
		}
		else throw new ReportIdNotFoundException("Report Not Found");
	}
		
	@Override
	public List<Report> viewReportsByPatientId(int patientId) throws ReportIdNotFoundException,PatientIdNotFoundException{
		if(patientRepository.existsById(patientId)) {
			List<Report> list = reportRepository.viewByPatientId(patientId);
			if(list.isEmpty()) throw new ReportIdNotFoundException("No Reports Found");
			else return list;
		}
		else throw new PatientIdNotFoundException("No Patient Found");
	}

	@Override
	public List<Report> viewReportsByDate(LocalDate date) throws ReportIdNotFoundException {
		if(reportRepository.viewByDate(date).isEmpty())	throw new ReportIdNotFoundException("No Reports Found");
		else return reportRepository.viewByDate(date);
	}
}
