package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dto.Patient;
import com.exceptions.PatientIdNotFoundException;
import com.repository.IfcPatientRepository;
import com.service.IfcPatientService;
import org.springframework.stereotype.Service;
@Service
public class PatientServiceImpl implements IfcPatientService{
	
	@Autowired
	private IfcPatientRepository patientRepository;
	
	@Override
	public Patient addPatient(Patient patient) {
		return patientRepository.save(patient);
	}

	@Override
	public Patient updatePatient(Patient patient) throws PatientIdNotFoundException {
		if(patientRepository.existsById(patient.getPatientId())) {
			Patient p = patientRepository.findById(patient.getPatientId()).get();
			p.setPatientName(patient.getPatientName());
			p.setGender(patient.getGender());
			p.setAddress(patient.getAddress());
			p.setPatientMobile(patient.getPatientMobile());
			p.setPatientEmail(patient.getPatientEmail());
			p.setPatientAge(patient.getPatientAge());
			p.setPatientPassword(patient.getPatientPassword());
			p.setPatientDOB(patient.getPatientDOB());
			patientRepository.save(p);
			return p;
		}
		else throw new PatientIdNotFoundException("Patient Not Found");
	}

	@Override
	public Patient deletePatient(int patientId) throws PatientIdNotFoundException {
		if(patientRepository.existsById(patientId)) {
			Patient pat = patientRepository.findById(patientId).get();
			patientRepository.delete(pat);
			return pat;
		}
		else throw new PatientIdNotFoundException("Patient Not Found");
	}

	@Override
	public List<Patient> viewPatientList() throws PatientIdNotFoundException {
		List<Patient> patList = patientRepository.findAll();
		if(patList.isEmpty()) throw new PatientIdNotFoundException("No Patients Found");
		return patList;
	}

	@Override
	public Patient viewPatient(int patientId) throws PatientIdNotFoundException {
		if(patientRepository.existsById(patientId)) {
			Patient pat = patientRepository.findById(patientId).get();
			return pat;
		}
		else throw new PatientIdNotFoundException("Patient Not Found");
	}
}
