package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dto.Test;
import com.exceptions.TestIdNotFoundException;
import com.repository.IfcTestRepository;
import com.service.IfcTestService;
import org.springframework.stereotype.Service;
@Service
public class TestServiceImpl implements IfcTestService{
	
	@Autowired
	private IfcTestRepository testRepository;

	@Override
	public Test addTest(Test test) {
		return testRepository.save(test);
	}

	@Override
	public Test updateTest(Test test) throws TestIdNotFoundException {
		if(testRepository.existsById(test.getTestId())) {
			Test t=testRepository.findById(test.getTestId()).get();
			t.setTestType(test.getTestType());
			t.setTestCost(test.getTestCost());
			t.setTestName(test.getTestName());
			testRepository.save(t);
			return t;
		}
		else throw new TestIdNotFoundException("Test Not Found");
	}

	@Override
	public Test removeTest(int testId) throws TestIdNotFoundException {
		if(testRepository.existsById(testId)){
			Test t=testRepository.findById(testId).get();
			testRepository.deleteById(testId);
			return t;
		}
		else throw new TestIdNotFoundException("Test Not Found");
	}

	@Override
	public Test viewTest(int testId) throws TestIdNotFoundException {
		if(testRepository.existsById(testId)){
			Test t = testRepository.findById(testId).get();
			return t;
		}
		else throw new TestIdNotFoundException("Test Not Found");
	}


	@Override
	public List<Test> viewAllTests() throws TestIdNotFoundException {
		List<Test> list = testRepository.findAll();
		if(list.isEmpty()) throw new  TestIdNotFoundException("No Tests found");
		return list;
	}	
}
