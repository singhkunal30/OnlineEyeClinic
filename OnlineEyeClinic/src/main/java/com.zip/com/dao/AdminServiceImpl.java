package com.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.Admin;
import com.repository.IfcAdminRepository;
import com.service.IfcAdminService;
@Service
public class AdminServiceImpl implements IfcAdminService{
	
	@Autowired
	private IfcAdminRepository adminRepository;
	
	@Override
	public Admin addAdmin(Admin admin) {
		return adminRepository.save(admin);
	}
	
	@Override
	public Admin updateAdmin(Admin admin) {
		Admin a = adminRepository.findById(admin.getAdminId()).get();
		a.setAdminUsername(admin.getAdminUsername());
		a.setAdminPassword(admin.getAdminPassword());
		adminRepository.save(a);
		return a;
	}
}
