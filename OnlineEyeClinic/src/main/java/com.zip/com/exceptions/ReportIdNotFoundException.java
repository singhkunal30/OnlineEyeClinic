package com.exceptions;

public class ReportIdNotFoundException extends Exception {
public ReportIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public ReportIdNotFoundException(String message) {
super(message);	// TODO Auto-generated constructor stub
}
}
