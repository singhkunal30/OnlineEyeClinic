package com.exceptions;

public class AppointmentIdNotFoundException extends Exception {
public AppointmentIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public AppointmentIdNotFoundException(String message) {
super(message);
}
}
