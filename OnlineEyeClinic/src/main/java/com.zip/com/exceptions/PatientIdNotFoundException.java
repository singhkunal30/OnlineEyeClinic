package com.exceptions;

public class PatientIdNotFoundException extends Exception {
public PatientIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public PatientIdNotFoundException(String message) {
super(message);
}
}
