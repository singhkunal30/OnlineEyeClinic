package com.exceptions;

public class InvalidAppointmentException extends Exception {
public InvalidAppointmentException() {
	// TODO Auto-generated constructor stub
}
public InvalidAppointmentException(String message) {
	super(message);
}
}
