package com.exceptions;

public class TestIdNotFoundException extends Exception {
public TestIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public TestIdNotFoundException(String message) {
	super(message);
}
}
