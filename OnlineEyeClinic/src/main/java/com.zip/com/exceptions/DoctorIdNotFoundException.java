package com.exceptions;

public class DoctorIdNotFoundException extends Exception {
public DoctorIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public DoctorIdNotFoundException(String message) {
	super(message);
}
}
